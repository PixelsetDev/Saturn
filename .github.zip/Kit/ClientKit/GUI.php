<?php

namespace Saturn\ClientKit;

class GUI
{
    public function Alert(string $Type, string $Title, string $Message, array $ButtonsText = null, array $ButtonsLinks = null)
    {
    }
}
