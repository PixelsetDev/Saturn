<?php

namespace Saturn;

class ClientKit
{
    public function __construct()
    {
        require_once 'Translate.php';
        require_once 'GUI.php';
    }
}
