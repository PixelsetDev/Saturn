# Saturn API
Welcome to the Saturn API.

## Powered by Boa
This software is a fork of Boa that has been modified to fetch settings from Saturn.