<?php

namespace SaturnServer\Authentication;

class JWT
{
}
