# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
| master  | :white_check_mark: |

## Reporting a Vulnerability

Found a security issue? Email security@lmwn.co.uk
