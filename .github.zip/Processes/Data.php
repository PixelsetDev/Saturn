<?php

const SATURN_VERSION = '1.0.0';
const SATURN_BRANCH = 'DEV';
const API_VERSION = 'v1';
